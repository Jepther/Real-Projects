package Group22;

import javax.swing.*;

public class MembersForm {
    private JPanel MainPanel;

    public JPanel getMainPanel() {
        return MainPanel;
    }

    public void setMainPanel(JPanel mainPanel) {
        MainPanel = mainPanel;
    }

    private JPanel NorthPanel;
}
