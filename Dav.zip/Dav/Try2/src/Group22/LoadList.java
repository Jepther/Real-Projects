package Group22;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class LoadList {
    private JPanel panel1;
    private JPanel NorthPanel;

    public LoadList() {
        CreateRegisterTable();


        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String firstname = SearchTF.getText();
                filter(firstname);
            }
        });
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deletefromDatabase();
            }
        });
    }

    public JPanel getMainPanel() {
        return MainPanel;
    }

    public void setMainPanel(JPanel mainPanel) {
        MainPanel = mainPanel;
    }


    private JPanel Centerpanel;
    private JScrollPane table;
    private JTable Rtable;
    private JPanel MainPanel;
    private JButton deleteButton;
    private JTextField SearchTF;
    private JButton searchButton;


    DefaultTableModel model = new DefaultTableModel();

    private void CreateRegisterTable(){

        Object[] columnName = new Object[7];

        columnName[0] ="ID";
        columnName[1] ="Lastname";
        columnName[2] ="Firstname";
        columnName[3] ="Username";
        columnName[4] ="Email";
        columnName[5] ="Password";
        columnName[6] ="Region";





        model.setColumnIdentifiers(columnName);

        Object[] rowData = new Object[7];


        connection connection = new connection();


        ArrayList<member> list = connection.getMembers();


        for (member members : list) {

            rowData[0] = members.getID();
            rowData[1] = members.getLastname();
            rowData[2] = members.getFirstname();
            rowData[3] = members.getUsername();
            rowData[4] = members.getEmail();
            rowData[5] = members.getPassword();
            rowData[6] = members.getRegion();



            model.addRow(rowData);
        }

        Rtable.setModel(model);



    }

    private void  filter(String firstname){



        TableRowSorter<DefaultTableModel> search = new TableRowSorter<>(model);
        Rtable.setRowSorter(search);
        search.setRowFilter(RowFilter.regexFilter(firstname));

    }


    public void deletefromDatabase()  {

        int i = Rtable.getSelectedRow();

        int d = Rtable.getSelectedRow();

        if (d >= 0) {
            int Id = Integer.parseInt(Rtable.getValueAt(d, 0).toString());


            try {
                Connection link = new connection().getmyConn();

                String sql = "DELETE FROM group22 WHERE ID ='" + Id + "'" ;

                PreparedStatement statement = link.prepareStatement(sql);

                int Update = statement.executeUpdate();

                if (Update > 0) {
                    JOptionPane.showMessageDialog(null,  Rtable.getValueAt(i,0)+" "+ "is Deleted Successfully");
                    System.out.println(Id);
                }
                else {
                    JOptionPane.showMessageDialog(null, "Deletion failed");
                    System.out.println(Id);


                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }



}
