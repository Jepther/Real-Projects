package Group22;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class RegisteredMembers {
    private JPanel panel1;
    private JPanel NorthPanel;
    private JTextField SearchTextfield;
    private JButton searchButton;
    private JPanel SouthPanel;
    private JButton deleteButton;
    private JPanel Centerpanel;
    private JTable Rtable;
    private JScrollPane table;


    DefaultTableModel model = new DefaultTableModel();
    public RegisteredMembers() {

        CreateRegisterTable();

    deleteButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            deletefromDatabase();
        }
    });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String lastname = SearchTextfield.getText();

                filter(lastname);
            }
        });
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deletefromDatabase();
            }
        });
    }






    public void deletefromDatabase()  {

        DefaultTableModel tbmodel = (DefaultTableModel)  Rtable.getModel();

        int i = Rtable.getSelectedRow();

        int d = Rtable.getSelectedRow();

        if (d >= 0) {

            int Id = Integer.parseInt(Rtable.getValueAt(d, 1).toString());


            try {
                Connection link = new connection().getmyConn();

                String sql = "DELETE FROM data WHERE ID ='" + Id + "'" ;

                PreparedStatement statement = link.prepareStatement(sql);

                int Update = statement.executeUpdate();

                if (Update > 0) {
                    JOptionPane.showMessageDialog(null, "Deleted\n"+ Rtable.getValueAt(i,1)+":" +" "+"ID Number="+" "+Id);
                    System.out.println(Id);
                }
                else {
                    JOptionPane.showMessageDialog(null, "Deletion failed");
                    System.out.println(Id);


                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }


    private void CreateRegisterTable(){

        Object[] columnName = new Object[7];


        columnName[0] = "ID";
        columnName[1] ="Last Name";
        columnName[2] ="First Name";
        columnName[3] ="Username";
        columnName[4] ="Email";
        columnName[5] = "Password";
        columnName[6] = "Region";




        model.setColumnIdentifiers(columnName);

        Object[] rowData = new Object[7];

       connection contact = new connection();

        ArrayList<member> list = contact.getMembers();


        for (member members : list) {

            rowData[0] = members.getID();
            rowData[1] = members.getLastname();
            rowData[2] = members.getFirstname();
            rowData[3] = members.getUsername();
            rowData[4] = members.getEmail();
            rowData[5] = members.getPassword();
            rowData[6] = members.getRegion();



            model.addRow(rowData);
        }

        Rtable.setModel(model);



    }

    private void  filter(String lastname){



        TableRowSorter<DefaultTableModel> search = new TableRowSorter<>(model);
        Rtable.setRowSorter(search);
        search.setRowFilter(RowFilter.regexFilter(lastname));

    }







}
