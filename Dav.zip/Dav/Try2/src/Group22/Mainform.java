package Group22;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.*;

public class Mainform {
    private JPanel mainpanel;
    private JPanel CenterPanel;
    private JPanel SouthPanel;
    private JTextField LastnameTF;
    private JTextField UsernameTF;
    private JTextField PasswordTF;
    private JButton createAccountButton;
    private JTextField FirstnameTF;
    private JTextField UserentryTF;
    private JTextField EmailTF;

    private JButton signupButton;
    private JButton ClearBtn;
    private JButton backButton;
    private JTextField PassEntryTF;
    private JComboBox RegionCOM;
    private JButton loginButton;
    private JButton clearButton;
    private JPanel MainNorthPanel;


    connection controller = new connection();

    Connection link = controller.getmyConn();

    public Mainform() {

        SouthPanel.setVisible(false);

        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SouthPanel.setVisible(true);
                CenterPanel.setVisible(false);


            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SouthPanel.setVisible(false);
                CenterPanel.setVisible(true);
            }
        });
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                insertData();

            }
        });
        ClearBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LastnameTF.setText("");
                FirstnameTF.setText("");
                UserentryTF.setText("");
                PassEntryTF.setText("");
                EmailTF.setText("");
            }
        });
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    try {


                        String sql = "SELECT * FROM group22 WHERE Username=? and Password=? ";

                        PreparedStatement statement = link.prepareStatement(sql);

                        statement.setString(1, UsernameTF.getText());
                        statement.setString(2, String.valueOf(PasswordTF.getText()));

                        ResultSet resultSet = statement.executeQuery();

                        if (resultSet.next()) {
                            JOptionPane.showMessageDialog(null, "Verified Successful");

                            JFrame Dwindow = new JFrame("Registered Members List");

                            Dwindow.setVisible(true);
                            Dwindow.setContentPane(new LoadList().getMainPanel());
                            Dwindow.setLocationRelativeTo(null);
                            Dwindow.setResizable(false);
                            Dwindow.setSize(10000, 10000);
                            Dwindow.pack();
                        } else {
                            JOptionPane.showMessageDialog(null, "Invalid username and password!");
                        }


                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                } catch (Exception el) {
                    JOptionPane.showMessageDialog(null, "Not Connected to the Xampp Server");
                }
            }


        });
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UsernameTF.setText("");
                PasswordTF.setText("");
            }
        });
    }

    public static void main(String[] args) {

        JFrame window = new JFrame("Group22 MainForm");


        window.setVisible(true);
        window.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        window.setContentPane(new Mainform().mainpanel);
        window.setJMenuBar(getmenubar());
        window.setSize(600, 400);
        window.setLocationRelativeTo(null);


    }

    private static JMenuBar getmenubar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu Filemenu = new JMenu("File");
        JMenu Helpmenu = new JMenu("Help");


        //Filemenu items
        JMenuItem open = new JMenuItem("Open");
        JMenuItem exit = new JMenuItem("Exit");

        //Helpmenu items
        JMenuItem About = new JMenuItem("About");


        //adding menubars

        menuBar.add(Filemenu);
        menuBar.add(Helpmenu);

        Filemenu.add(open);
        Filemenu.addSeparator();
        Filemenu.add(exit);

        Helpmenu.add(About);

        //File Mnemonics
        Filemenu.setMnemonic(KeyEvent.VK_F);
        Helpmenu.setMnemonic(KeyEvent.VK_H);


        //MenuItem Accelerators
        open.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
        About.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));


        //About
        About.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JWindow dialog = new JWindow();

                dialog.setContentPane(new MembersForm().getMainPanel());
                dialog.setLocationRelativeTo(null);
                dialog.pack();
                dialog.setVisible(true);


            }
        });
        //exitItem
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int exit = JOptionPane.showConfirmDialog(null,
                        "Do you want to exit Application?", "Confirm exit", JOptionPane.OK_CANCEL_OPTION);
                if (exit == JOptionPane.OK_OPTION) {
                    System.exit(0);
                }
            }
        });

        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {

                    JFrame Dwindow = new JFrame("Load List of Registered Members");

                    Dwindow.setContentPane(new ViewList().getMainPanel());
                    Dwindow.setVisible(true);
                    Dwindow.setLocationRelativeTo(null);
                    Dwindow.pack();

                } catch (Exception sqlException) {
                    JOptionPane.showMessageDialog(null, "Not Connected to mysql");
                }
            }
        });

        return menuBar;


    }


    public void insertData() {

        connection link = new connection();
        Connection myconnection = link.getmyConn();

  /*      Date today = new Date();
        SimpleDateFormat format = new SimpleDateFormat("DD/MM/YYYY");
        String dateString = format.format(today);
*/

        try {


            DatabaseMetaData dmD = myconnection.getMetaData();
            ResultSet resultSet = dmD.getTables(null, null, " group22", null);

            String Sql = "INSERT INTO  group22 VALUES (?,?,?,?,?,?,?)";


            PreparedStatement statement = myconnection.prepareStatement(Sql);


            int dataInserted = 0;

            if (resultSet.next()) {
                statement.setInt(1, 0);
                statement.setString(2, LastnameTF.getText());
                statement.setString(3, FirstnameTF.getText());
                statement.setString(4, UserentryTF.getText());
                statement.setString(5, EmailTF.getText());
                statement.setString(6, PassEntryTF.getText());
                statement.setString(7, String.valueOf(RegionCOM.getSelectedItem()));


                dataInserted = statement.executeUpdate();

            }

            myconnection.close();
            statement.close();


            if (dataInserted > 0) {
                JOptionPane.showMessageDialog(null, FirstnameTF.getText() + " " + "is" + " " + "Registered Successfully");
            } else {
                JOptionPane.showMessageDialog(null, "Registration Failed");
            }


        } catch (Exception e) {

            try {


                JOptionPane.showMessageDialog(null, UserentryTF.getText() + " " + "is already Registered");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null,"Not Connected to xampp server");

            }

        }


    }
}




