package Group22;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;

public class connection {


    public Connection myConn;



    public  Connection getmyConn () {

        try {
            String url = "jdbc:mysql://localhost:3306/group22";
            String user = "root";
            String password = "";

            try {

                myConn = DriverManager.getConnection(url, user, password);
                JOptionPane.showMessageDialog(null, "Connected Successfully");
            }
            catch (Exception exp){
                JOptionPane.showMessageDialog(null,"Not Connected to xampp server");

            }


        } catch (Exception e) {

            JOptionPane.showMessageDialog(null,"Not Connected to xampp server");

        }


        return myConn;
    }






    //members from database
    public ArrayList<member> getMembers(){
        ArrayList<member> list = new ArrayList<>();

        member fromDatabase;


        {
            try {
                String SQL = "SELECT * FROM  group22 ";

                PreparedStatement statement = getmyConn().prepareStatement(SQL);

                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()){
                    fromDatabase = new member(
                            resultSet.getInt("ID"),
                            resultSet.getString("Firstname"),
                            resultSet.getString("Lastname"),
                            resultSet.getString("Username"),
                            resultSet.getString("Email"),
                            resultSet.getString("Password"),
                            resultSet.getString("Region"));

                    list.add(fromDatabase);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return list;
    }
}
