package Group22;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewList {
    private JPanel MainPanel;
    private JPanel panel1;

    public JPanel getMainPanel() {
        return MainPanel;
    }

    public void setMainPanel(JPanel mainPanel) {
        MainPanel = mainPanel;
    }

    private JPanel NorthPanel;
    private JPanel Centerpanel;
    private JScrollPane table;
    private JTable Rtable;

    DefaultTableModel model = new DefaultTableModel();


    public ViewList() {
        CreateRegisterTable();




    }

    private void CreateRegisterTable(){

        Object[] columnName = new Object[3];

        columnName[0] ="ID Number";
        columnName[1] ="Surname";
        columnName[2] ="Firstname";





        model.setColumnIdentifiers(columnName);

        Object[] rowData = new Object[3];

        connection contact = new connection();

        ArrayList<member> list = contact.getMembers();


        for (member members : list) {

            rowData[0] = members.getID();
            rowData[1] = members.getFirstname();
            rowData[2] = members.getLastname();


            model.addRow(rowData);
        }

       Rtable.setModel(model);



    }


}
