package Group22;

public class member {

    private int ID;
    private String Lastname;

    private String firstname;
    private String Username;
    private String password;

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String lastname) {
        Lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    private String Email;
    private String region;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public member(int ID, String firstName, String LastName, String username, String email, String Region, String password) {

        this.ID=ID;
        this.firstname = firstName;
        this.Lastname = LastName;
        this.Username = username;
        this.Email = email;
        this.password = password;
        this.region = Region;

    }
}
